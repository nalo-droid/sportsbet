import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import SportsBetting from './components/SportsBetting';
import Games from './components/Games';
import Register from './components/Register';
import Login from './components/Login';
import Admin from './components/Admin';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/games" element={<Games />} />
        <Route path="/sports-betting" element={<SportsBetting />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </Router>
  );
}

export default App; 