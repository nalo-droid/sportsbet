import React, { useEffect, useState } from 'react';
import Header from './Header';
import apiUrl from './apiUrl';
import Filter from './Filter';
import useUserProfile from '../hooks/useUserProfile';
import Button from './Button';
import AllBets from './AllBets';

const SportsBetting = () => {
  const [matches, setMatches] = useState([]);
  const [error, setError] = useState(null);
  const [bets, setBets] = useState([]); 
  const [filter, setFilter] = useState({ league: '', date: '', team: '' });
  const [leagues, setLeagues] = useState([]);
  const [teams, setTeams] = useState([]);
  const [stake, setStake] = useState(100); 
  const [loading, setLoading] = useState(true); // Add loading state
  const user = useUserProfile();
  console.log(user)
  useEffect(() => {
    const fetchMatches = async () => {
      try {
        const response = await fetch(`${apiUrl}/api/matches`);
        const data = await response.json();
        setMatches(data);
        setLeagues([...new Set(data.map(match => match.competition.name))]);
        setTeams([...new Set(data.flatMap(match => [match.homeTeam.name, match.awayTeam.name]))]);
      } catch (error) {
        setError(error.message);
      }
    };

    const fetchBets = async () => {
      try {
        const response = await fetch(`${apiUrl}/api/bets/bets`);
        const data = await response.json();
        setBets(data);
      } catch (error) {
        setError(error.message);
      }
    };

    const fetchData = async () => {
      await fetchMatches();
      await fetchBets();
      setLoading(false); // Set loading to false after data is fetched
    };

    fetchData();
  }, []);

  const createBet = async (matchId, betType, amount, homeTeam, awayTeam) => {
    try {
      const response = await fetch(`${apiUrl}/api/bets/create`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user._id,
          matchId,
          betType,
          amount,
          homeTeam,
          awayTeam,
        }),
      });
      const data = await response.json();
      setBets([...bets, data]);
      // window.location.reload();
    } catch (error) {
      setError(error.message);
    }
  };

  const acceptBet = async (matchId, betType, amount, homeTeam, awayTeam) => {
    try {
      const response = await fetch(`${apiUrl}/api/bets/accept/${matchId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user._id,
          betType,
          amount,
          homeTeam,
          awayTeam,
        }),
      });
      const data = await response.json();
      setBets(bets.map(bet => (bet.matchId === matchId ? data : bet)));
    } catch (error) {
      setError(error.message);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilter({ ...filter, [name]: value });
  };

  const handleStakeChange = (e) => {
    setStake(e.target.value);
  };

  const filteredMatches = matches.filter(match => {
    return (
      (filter.league ? match.competition.name === filter.league : true) &&
      (filter.date ? match.utcDate.split('T')[0] === filter.date : true) &&
      (filter.team ? match.homeTeam.name === filter.team || match.awayTeam.name === filter.team : true)
    );
  });

  const today = new Date().toISOString().split('T')[0];

  return (
    <div>
      <Header />
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <h2 className="text-4xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">Sports Betting</h2>
        {/* {error && <p className="text-red-500 mb-4">Error: {error}</p>} */}
        {loading ? (
          <div className="flex justify-center items-center h-screen">
            <p className="text-2xl font-bold text-blue-400">Loading...</p>
          </div>
        ) : (
          <>
            <Filter filter={filter} leagues={leagues} teams={teams} handleFilterChange={handleFilterChange} today={today} />
            <div className="lg:hidden mb-6 bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-700">
              <label htmlFor="stake" className="block mb-2 text-lg font-medium text-blue-300">Stake Amount:</label>
              <input
                id="stake"
                type="number"
                value={stake}
                onChange={handleStakeChange}
                className="p-2 border rounded text-white bg-gray-700 border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 w-full"
              />
            </div>
            <div className="flex flex-col lg:flex-row space-y-6 lg:space-y-0 lg:space-x-4 p-4">
              <div className="lg:w-2/5 bg-gray-800 rounded-lg shadow-lg border border-gray-700 flex flex-col">
                <h3 className="text-2xl font-bold p-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600 border-b border-gray-700">Available Matches</h3>
                <div className="overflow-y-auto flex-grow p-6 custom-scrollbar">
                  {filteredMatches.map(match => (
                    <div key={match.id} className="bg-gray-700 rounded-lg p-6 mb-6 shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-600">
                      <div className="text-xl font-medium mb-4 text-blue-300">
                        {match.homeTeam.name} vs {match.awayTeam.name}
                      </div>
                      <div className="text-lg mb-4 text-gray-400">
                        {new Date(match.utcDate).toLocaleDateString()} at {new Date(match.utcDate).toLocaleTimeString()}
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <Button onClick={() => createBet(match.id, 'home', stake, match.homeTeam.name, match.awayTeam.name)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors duration-300 lg:py-1 lg:px-2 text-sm">Home</Button>
                        <Button onClick={() => createBet(match.id, 'draw', stake, match.homeTeam.name, match.awayTeam.name)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors duration-300 lg:py-1 lg:px-2 text-sm">Draw</Button>
                        <Button onClick={() => createBet(match.id, 'away', stake, match.homeTeam.name, match.awayTeam.name)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors duration-300 lg:py-1 lg:px-2 text-sm">Away</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <AllBets bets={bets} stake={stake} acceptBet={acceptBet} />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SportsBetting;