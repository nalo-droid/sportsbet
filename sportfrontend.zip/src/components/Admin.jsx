import React, { useEffect, useState } from 'react';
import { FaUser, FaFutbol } from 'react-icons/fa'; 
import apiUrl from './apiUrl';

function Admin() {
  const [bets, setBets] = useState([]);

  useEffect(() => {
    const fetchBets = async () => {
      try {
        const response = await fetch(`${apiUrl}/api/admin/bets`);
        const data = await response.json();
        setBets(data);
      } catch (error) {
        console.error('Error fetching bets:', error);
      }
    };

    fetchBets();
  }, []);

  const creditWinner = async (betId, userId) => {
    try {
      const response = await fetch(`${apiUrl}/api/admin/bet/credit-winner`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            userId,
            betId,
          }),
      });
      if (response.ok) {
        console.log(`Successfully credited user ${userId} for bet ${betId}`);
      } else {
        console.error('Failed to credit user:', await response.json());
      }
    } catch (error) {
      console.error('Error crediting user:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-4">
      <h1 className="text-4xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">Admin Bets</h1>
      {bets.map(bet => (
        <div key={bet._id} className="bg-gray-700 rounded-lg p-6 mb-6 shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-600">
          <div className="flex items-center mb-2 text-xl font-medium text-blue-300">
            <FaFutbol className="mr-2" />
            <span>{bet.homeTeam} vs {bet.awayTeam}</span>
          </div>
          <div className="text-lg text-gray-400 mb-2">Match ID: {bet.matchId}</div>
          <div className="text-lg text-gray-400 mb-2">Status: {bet.status}</div>
          <div className="mt-2">
            <h2 className="text-2xl font-bold mb-2">Bets:</h2>
            {bet.bets.map(b => (
              <div key={b._id} className="flex items-center mb-2 text-lg text-gray-400">
                <FaUser className="mr-2" />
                <span className="mr-2">{b.userId.username} (ID: {b.userId._id})</span>
                <span className="mr-2">Bet Type: {b.betType}</span>
                <span>Amount: ${b.amount}</span>
                <button
                  className="ml-4 px-2 py-1 bg-blue-500 text-white rounded"
                  onClick={() => creditWinner(bet._id, b.userId._id)}
                >
                  Credit
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export default Admin;