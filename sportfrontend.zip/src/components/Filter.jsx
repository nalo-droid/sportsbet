import React from 'react';

const Filter = ({ filter, leagues, teams, handleFilterChange, today }) => {
  return (
    <div className="mb-6 flex flex-wrap gap-4 justify-center">
      <select
        name="league"
        value={filter.league}
        onChange={handleFilterChange}
        className="p-2 border rounded text-white bg-gray-800 border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <option value="">Filter by league</option>
        {leagues.map((league, index) => (
          <option key={index} value={league}>{league}</option>
        ))}
      </select>
      <input
        type="date"
        name="date"
        value={filter.date}
        onChange={handleFilterChange}
        min={today}
        className="p-2 border rounded text-white bg-gray-800 border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
      <select
        name="team"
        value={filter.team}
        onChange={handleFilterChange}
        className="p-2 border rounded text-white bg-gray-800 border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <option value="">Filter by team</option>
        {teams.map((team, index) => (
          <option key={index} value={team}>{team}</option>
        ))}
      </select>
    </div>
  );
};

export default Filter;
