function Footer() {
  return ( 
      <div className="min-h-screen bg-gray-900 text-white"> 

        <footer className="bg-gray-800 py-6 mt-8">
          <div className="container mx-auto px-4 text-center text-gray-400">
            © 2024 Betting Platform. All rights reserved.
          </div>
        </footer>
      </div> 
  );
}

export default Footer; 