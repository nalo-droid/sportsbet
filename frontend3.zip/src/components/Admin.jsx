import React, { useState, useEffect } from 'react';
import { FaFutbol, FaPlus } from 'react-icons/fa';
import apiUrl from './apiUrl';

function Admin() {
  const [formData, setFormData] = useState({
    homeTeam: '',
    awayTeam: '',
    amount: ''
  });
  const [message, setMessage] = useState({ text: '', isError: false });
  const [matches, setMatches] = useState([]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`${apiUrl}/api/admin/create-match`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      const data = await response.json();
      
      if (response.ok) {
        setMessage({ text: 'Match created successfully!', isError: false });
        setFormData({ homeTeam: '', awayTeam: '', amount: '' });
      } else {
        setMessage({ text: data.message || 'Error creating match', isError: true });
      }
    } catch (error) {
      setMessage({ text: 'Failed to create match', isError: true });
    }
  };

  const fetchMatches = async () => {
    try {
      const response = await fetch(`${apiUrl}/api/matches/list`);
      const data = await response.json();
      
      if (response.ok) {
        setMatches(data);
      } else {
        setMessage({ text: data.message || 'Error fetching matches', isError: true });
      }
    } catch (error) {
      setMessage({ text: 'Failed to fetch matches', isError: true });
    }
  };

  const getBetTypeStats = async (match, betType) => {
    const betsOfType = match.bets.filter(bet => bet.betType === betType);
    const scoreInput = prompt('Enter scores (home,away):');
    
    if (scoreInput) {
      const [homeScore, awayScore] = scoreInput.split(',').map(score => score.trim());
       
      try {
        const response = await fetch(`${apiUrl}/api/admin/update-match-score`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            matchId: match._id,
            betType,
            homeScore,
            awayScore
          })
        });

        const data = await response.json();
        if (response.ok) {
          console.log('Score update response:', data);
          // Optionally refresh the matches list
          fetchMatches();
        } else {
          console.error('Error updating score:', data.message);
        }
      } catch (error) {
        console.error('Failed to update score:', error);
      }
    }
  };

  const handleStart = async (matchId) => {
    try {
      const response = await fetch(`${apiUrl}/api/admin/updateStatus`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          matchId,
          status: 'inplay'
        })
      });

      const data = await response.json();
      if (response.ok) {
        fetchMatches(); // Refresh the matches list
        setMessage({ text: 'Match started successfully', isError: false });
      } else {
        setMessage({ text: data.message || 'Error starting match', isError: true });
      }
    } catch (error) {
      setMessage({ text: 'Failed to start match', isError: true });
    }
  };

  const handleDelete = async (matchId) => {
    if (!window.confirm('Are you sure you want to delete this match?')) {
      return;
    }

    try {
      const response = await fetch(`${apiUrl}/api/bets/delete/${matchId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      const data = await response.json();
      if (response.ok) {
        fetchMatches(); // Refresh the matches list
        setMessage({ text: 'Match deleted successfully', isError: false });
      } else {
        setMessage({ text: data.message || 'Error deleting match', isError: true });
      }
    } catch (error) {
      setMessage({ text: 'Failed to delete match', isError: true });
    }
  };

  useEffect(() => {
    fetchMatches();
  }, []);

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="flex items-center gap-3 mb-6">
        <FaFutbol className="text-3xl text-blue-600" />
        <h1 className="text-2xl font-bold">Create New Match</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Home Team</label>
          <input
            type="text"
            name="homeTeam"
            value={formData.homeTeam}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Away Team</label>
          <input
            type="text"
            name="awayTeam"
            value={formData.awayTeam}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Amount</label>
          <input
            type="number"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <button
          type="submit"
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          <FaPlus /> Create Match
        </button>
      </form>

      {message.text && (
        <div className={`mt-4 p-3 rounded-md ${message.isError ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
          {message.text}
        </div>
      )}

      <div className="mt-8">
        <h2 className="text-xl font-bold mb-4">Existing Matches</h2>
        <div className="space-y-4">
          {matches.map((match) => (
            <div key={match._id} className="p-4 border rounded-md shadow-sm">
              <div className="flex justify-between items-center mb-2">
                <p className="font-medium text-lg">{match.homeTeam} vs {match.awayTeam}</p>
                <span className={`px-2 py-1 rounded text-sm ${
                  match.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {match.status}
                </span>
              </div>
              <p className="text-gray-600 mb-2">Stake Amount: ${match.amount}</p>
              <p className="text-gray-600 mb-2">Total Stake: ${match.amount * match.bets.length}</p>
              
              <div className="flex gap-2 mt-3">
                <button
                  onClick={() => getBetTypeStats(match, 'home')}
                  className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
                >
                  Action
                </button> 
                <button
                  onClick={() => handleStart(match._id)}
                  className="px-3 py-1 bg-green-500 text-white rounded hover:bg-red-600"
                >
                  Start Game
                </button>
                <button
                  onClick={() => handleDelete(match._id)}
                  className="px-3 py-1 bg-red-700 text-white rounded hover:bg-red-800"
                >
                  Delete
                </button>
              </div>

              {match.bets.length > 0 && (
                <div className="mt-3">
                  <p className="font-medium mb-2">Bets:</p>
                  <div className="space-y-2">
                    {match.bets.map((bet) => (
                      <div key={bet._id} className="bg-gray-50 p-2 rounded-md">
                        <p className="text-sm">
                          <span className="font-medium">{bet.userId.username}</span> - 
                          Bet on: <span className="capitalize">{bet.betType}</span>
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Admin;